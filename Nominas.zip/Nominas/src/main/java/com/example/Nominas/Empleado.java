package com.example.Nominas;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "empleado")
public class Empleado {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long  id;
    
    @Column(name = "id_empresa")
    private int id_empresa;
    
    @Column(name = "nombre")
    private String nombre;
    
    @Column(name = "apellidos")
    private String apellidos;
    
    @Column(name = "domicilio")
    private String domicilio;
    
    @Column(name = "dni")
    private String dni;
    
    @Column(name = "ss")
    private String ss;
    
    @Column(name = "fecha_alta")
    private String fecha_alta;
    
    @Column(name = "fecha_baja")
    private String fecha_baja;
    
    @Column(name = "categoria")
    private int categoria;
    
    @Column(name = "nivel")
    private int nivel;
    
    @Column(name = "letra")
    private char letra;
    
    @Column(name = "plus_capacitacion_profesional")
    private String plus_capacitacion_profesional;
    
    @Column(name = "plus_transporte")
    private int plus_transporte;
    
    @Column(name = "plus_dieta")
    private float plus_dieta;
    
    @Column(name = "antiguedad")
    private String antiguedad;
    
    @Column(name = "tipo_de_contrato")
    private String tipo_de_contrato;
    
    @Column(name = "jornada")
    private String jornada;

    public long getId() {
        return id;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getDni() {
        return dni;
    }

    public String getSs() {
        return ss;
    }

    public String getFecha_alta() {
        return fecha_alta;
    }

    public String getFecha_baja() {
        return fecha_baja;
    }

    public int getCategoria() {
        return categoria;
    }

    public int getNivel() {
        return nivel;
    }

    public char getLetra() {
        return letra;
    }

    public String getAntiguedad() {
        return antiguedad;
    }

    public String getTipo_de_contrato() {
        return tipo_de_contrato;
    }

    public String getJornada() {
        return jornada;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setSs(String ss) {
        this.ss = ss;
    }

    public void setFecha_alta(String fecha_alta) {
        this.fecha_alta = fecha_alta;
    }

    public void setFecha_baja(String fecha_baja) {
        this.fecha_baja = fecha_baja;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public void setLetra(char letra) {
        this.letra = letra;
    }

    public void setAntiguedad(String antiguedad) {
        this.antiguedad = antiguedad;
    }

    public void setTipo_de_contrato(String tipo_de_contrato) {
        this.tipo_de_contrato = tipo_de_contrato;
    }

    public void setJornada(String jornada) {
        this.jornada = jornada;
    }

    public String toStringCategoria() {
        return String.valueOf(categoria);
    }

    public String getPlus_capacitacion_profesional() {
        return plus_capacitacion_profesional;
    }

    public void setPlus_capacitacion_profesional(String plus_capacitacion_profesional) {
        this.plus_capacitacion_profesional = plus_capacitacion_profesional;
    }

    public int getPlus_transporte() {
        return plus_transporte;
    }

    public void setPlus_transporte(int plus_transporte) {
        this.plus_transporte = plus_transporte;
    }

    public float getPlus_dieta() {
        return plus_dieta;
    }

    public void setPlus_dieta(float plus_dieta) {
        this.plus_dieta = plus_dieta;
    }

   
    
}
