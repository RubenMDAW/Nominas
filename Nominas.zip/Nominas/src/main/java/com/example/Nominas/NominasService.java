/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Nominas;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Rubén
 */
@Service
public class NominasService {

    @Autowired
    NominasRepository repository;

    @Autowired
    EmpleadoRepository repositoryEmpleado;

    @Autowired
    EmpresaRepository repositoryEmpresa;

    public void nominasInformation() throws ParseException, ParserConfigurationException, SAXException, IOException, DocumentException {

        List<Empleado> listaEmpleados = getAllEmpleados();

        List<Nominas> listaDeNominas = repository.listNominasMes();
        Iterable<Nominas> iterableNominasABorrar = listaDeNominas;
        repository.deleteAll(iterableNominasABorrar);

        for (int i = 0; i < numeroEmpleado(listaEmpleados); i++) {

            Nominas nominaGenerada = new Nominas();
            Empleado empleadoActual = listaEmpleados.get(i);
            Empresa empresa = repositoryEmpresa.findById(Long.valueOf(empleadoActual.getId_empresa())).get();

            nominaGenerada.setId_empresa(empleadoActual.getId_empresa());
            nominaGenerada.setId_trabajador(Math.toIntExact(empleadoActual.getId()));
            int mesActual = LocalDate.now().getMonthValue();
            if (fechaInicioFinal(empleadoActual.getFecha_alta(), mesActual, 01)) {
                nominaGenerada.setFecha_inicio(empleadoActual.getFecha_alta());
            } else {
                nominaGenerada.setFecha_inicio("2022-0" + mesActual + "-01");
            }

            if (fechaInicioFinal(empleadoActual.getFecha_baja(), mesActual, fechaFinalMes(mesActual))) {
                nominaGenerada.setFecha_final("2022-0" + mesActual + "-" + fechaFinalMes(mesActual));
            } else {
                nominaGenerada.setFecha_final(empleadoActual.getFecha_baja());
            }

            // EMPRESA
            nominaGenerada.setEmpresa(empresa.getNombre());
            nominaGenerada.setDomicilio(empresa.getDomicilio());
            nominaGenerada.setCif(empresa.getCif());
            nominaGenerada.setCcc(empresa.getCcc());

            // TRABAJADOR
            nominaGenerada.setTrabajador(empleadoActual.getNombre() + " " + empleadoActual.getApellidos());
            nominaGenerada.setNif(empleadoActual.getDni());
            nominaGenerada.setSs(empleadoActual.getSs());
            nominaGenerada.setCategoria_profesional("SACAR BASEDEDATOS,AGREGAR CAMPO");
            nominaGenerada.setGrupo_cotizacion(empleadoActual.getCategoria());
            nominaGenerada.setFecha_antiguedad(empleadoActual.getFecha_alta());

            // DEVENGOS
            String salario_baseString = salarioXML(empleadoActual);
            float salario_base = Float.valueOf(salario_baseString) / 15;
            float extraordinarias = salario_base / 12;
            nominaGenerada.setSalario_base(salario_base);
            if (mesActual == 6 || mesActual == 12) {
                nominaGenerada.setVacaciones(salario_base);
            } else {
                nominaGenerada.setVacaciones(0);
            }
            nominaGenerada.setExtraordinarias(extraordinarias);
            nominaGenerada.setTotal_devengado(nominaGenerada.getSalario_base() + nominaGenerada.getExtraordinarias());
            nominaGenerada.setContingencias_comunes(4.70f * nominaGenerada.getTotal_devengado() / 100);
            if (empleadoActual.getTipo_de_contrato().equals("Temporal")) {
                nominaGenerada.setDesempleo(1.60f * nominaGenerada.getTotal_devengado() / 100);
            } else {
                nominaGenerada.setDesempleo(1.55f * nominaGenerada.getTotal_devengado() / 100);
            }
            nominaGenerada.setFormacion_profesional(0.10f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setTotal_aportaciones(nominaGenerada.getContingencias_comunes() + nominaGenerada.getDesempleo() + nominaGenerada.getFormacion_profesional());

            nominaGenerada.setIrpf(2f * nominaGenerada.getTotal_devengado() / 100); //PORCENTAJE GUARDAR BBDD
            nominaGenerada.setTotal_a_deducir(nominaGenerada.getTotal_aportaciones() + nominaGenerada.getIrpf());

            nominaGenerada.setLiquido_total_a_percibir(nominaGenerada.getTotal_devengado() - nominaGenerada.getTotal_a_deducir());

            // CONTINGENCIAS EMPRESA
            nominaGenerada.setRemuneracion_personal(nominaGenerada.getSalario_base() + nominaGenerada.getVacaciones());
            nominaGenerada.setProrrata_pagas_extras(nominaGenerada.getExtraordinarias());

            nominaGenerada.setBase_cotizacion_ss(23.60f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setAt_ep(1.5f * nominaGenerada.getTotal_devengado() / 100);
            if (empleadoActual.getTipo_de_contrato().equals("Indefinido")) {
                nominaGenerada.setE_desempleo(5.50f * nominaGenerada.getTotal_devengado() / 100);
            } else {
                nominaGenerada.setE_desempleo(6.70f * nominaGenerada.getTotal_devengado() / 100);
            }
            nominaGenerada.setE_formacion_profesional(0.6f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setFondo_garantia_social(0.2f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setTotal_aportacion_empresarial(nominaGenerada.getBase_cotizacion_ss() + nominaGenerada.getAt_ep() + nominaGenerada.getE_desempleo() + nominaGenerada.getE_formacion_profesional() + nominaGenerada.getFondo_garantia_social());

            createDirectoryUser(empleadoActual);
            generarPDF(nominaGenerada, empleadoActual, empresa);
            passZip(empleadoActual);
            repository.save(nominaGenerada);

        }
    }

    public int fechaFinalMes(int mes) {
        switch (mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 2:
                return 28;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 0;
        }
    }

    public boolean fechaInicioFinal(String fechaIncorporacion, int mesActual, int dia) throws ParseException {
        String fechaI1 = fechaIncorporacion;
        String fechaF2 = "2022-" + mesActual + "-" + dia;
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

        Date fecha1 = formato.parse(fechaI1);
        Date fecha2 = formato.parse(fechaF2);

        if (fecha1.after(fecha2)) {
            return true;
        }
        return false;
    }

    public String salarioXML(Empleado empleadoActual) throws ParserConfigurationException, SAXException, IOException {

        final String FILENAME = "/home/ismael/Escritorio/convenio.xml";
        int empleado_grupo = empleadoActual.getCategoria();
        int empleado_nivel = empleadoActual.getNivel();
        char empleado_letraChar = empleadoActual.getLetra();
        String empleado_letra = Character.toString(empleado_letraChar);

        // instancia la factoria
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        // Parsear el fichero de XML
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File(FILENAME));

        // Quitar infromacion redundante
        doc.getDocumentElement().normalize();
        // doc  busca root devuelve nombre de la raiz o root

        NodeList nodeListGrupoProfesional = doc.getElementsByTagName("grupo_profesional");

        Node nNode_grupo_profesional = nodeListGrupoProfesional.item(empleado_grupo - 1);

        Element element_NivelCat = (Element) nNode_grupo_profesional;

        NodeList nNode_grupo_profesional_hijos = element_NivelCat.getElementsByTagName("niveles_de_categorias");

        Element element_Nivel = (Element) nNode_grupo_profesional_hijos.item(0);

        NodeList nodeNivel = element_Nivel.getElementsByTagName("nivel");
        for (int i = 0; i < nodeNivel.getLength(); i++) {

            Node nodos_Niveles = nodeNivel.item(i);

            Element elementoNivel = (Element) nodos_Niveles;

            String nivel = elementoNivel.getAttribute("numero");
            /*if (nodeNivel.getLength() == 1 || Integer.parseInt(nivel) == empleado_nivel) {
            NodeList nodelist_nombrecategoria = elementoNivel.getElementsByTagName("nombre_categoria");
            for (int j = 0; j < nodelist_nombrecategoria.getLength(); j++) {
            Node nodos_nombrecat = nodelist_nombrecategoria.item(j);
            
            Element elementosNombreCat = (Element) nodos_nombrecat;
            
            String letra = elementosNombreCat.getAttribute("letra");
            
            if (letra.equals(String.valueOf(empleado_letra))) {
            //System.out.println(elementosNombreCat.getTextContent());
            }
            }
            }// el ombre del los empleados no hace falta comprobar*/

            NodeList nNode_grupo_profesional_salarios = element_NivelCat.getElementsByTagName("salario");

            for (int j = 0; j < nNode_grupo_profesional_salarios.getLength(); j++) {
                Element element_salarioActual = (Element) nNode_grupo_profesional_salarios.item(j);
                if (Integer.parseInt(element_salarioActual.getAttribute("nivel")) == empleado_nivel) {
                    String letra = element_salarioActual.getAttribute("letra");
                    if (empleado_letra.equals("0") || letra.equals(empleado_letra)) {
                        return element_salarioActual.getTextContent();
                    }
                }
            }

        }
        return "";
    }

    public List getAllEmpleados() {
        List<Empleado> listaEmpleados = repositoryEmpleado.findAll();
        return listaEmpleados;
    }

    public static int numeroEmpleado(List<Empleado> list) {
        return list.size();
    }

    public List getNominasABorrar() {
        List<Nominas> listaNominasABorrar = repository.listNominasMes();
        return listaNominasABorrar;
    }

    public void generarPDF(Nominas nomina, Empleado empleado, Empresa empresa) throws FileNotFoundException, DocumentException {

        com.itextpdf.text.Document document = new com.itextpdf.text.Document();
        String[] apellido = empleado.getApellidos().split(" ");
        String[] fecha = nomina.getFecha_final().split("-");
        PdfWriter.getInstance(document, new FileOutputStream("./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni() + "/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + fecha[1] + "_" + fecha[0] + ".pdf"));
        document.open();
        //com.itextpdf.text.Font negrita = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
        Font negrita = new Font(Font.FontFamily.COURIER, 14, Font.BOLDITALIC);
        /* Chunk c1 = new Chunk(empresa.getNombre() + "\n", font);
        Chunk c14 = new Chunk("Domicilio: " + empresa.getDomicilio() + "\n", font);
        Chunk c2 = new Chunk("CIF: " + empresa.getCif() + "\n", font);
        Chunk c3 = new Chunk("CCC: " + empresa.getCcc() + "\n", font);
        Chunk c4 = new Chunk(empleado.getNombre() + " " + empleado.getApellidos() + "\n", font);
        Chunk c5 = new Chunk("DNI: " + empleado.getDni() + "\n", font);
        Chunk c6 = new Chunk("Nº afiliación a la S.S: " + empleado.getSs() + "\n", font);
        Chunk c7 = new Chunk("Grupo profesional: AÑADIR A BASE DE DATOS" + "\n", font);
        Chunk c8 = new Chunk("Grupo cotización: " + empleado.toStringCategoria() + "\n", font);
        Chunk c9 = new Chunk("F.Antigüedad: " + empleado.getFecha_alta() + "\n", font);
        Chunk c10 = new Chunk("Periodo de Liquidacion del " + nomina.getFecha_inicio() + " a " + nomina.getFecha_final() + "\n", font);
        int totalDias = Integer.parseInt(nomina.getFecha_final().substring(8)) - Integer.parseInt(nomina.getFecha_inicio().substring(8)) + 1;
        Chunk c11 = new Chunk("Total dias: " + totalDias + "\n", font);
        Chunk c12 = new Chunk("DEVENGOS" + "\n", font);
        Chunk c13 = new Chunk("1. Percepciones salariales \n"
                + "Salario base" + nomina.getSalario_base() + "\n"
                + "P.P. gratificaciones \n"
                + "Extraodinarias " + nomina.getExtraordinarias() + "\n"
                + "Total devengado" + nomina.getTotal_devengado() + "\n",
                font);
         */
 /*  Chunk c14 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c15 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c16 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c17 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c18 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c19 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c20 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c21 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c22 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c23 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c24 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c1 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c1 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c1 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);
        Chunk c1 = new Chunk(String.valueOf(nomina.getLiquido_total_a_percibir()), font);*/
        Phrase frase1 = new Phrase();
        Paragraph parrafo = new Paragraph();
        PdfPTable table = new PdfPTable(3);
        PdfPTable table2 = new PdfPTable(5);

        table.getDefaultCell().setBorder(0);
        table.setWidthPercentage(100);
        table.addCell(new Phrase("EMPRESA", negrita));
        table.addCell("");
        table.addCell(new Phrase("EMPLEADO", negrita));
        table.addCell("Nombre:\n" + empresa.getNombre());
        table.addCell("");
        table.addCell("Nombre:\n" + empleado.getNombre() + " " + empleado.getApellidos());
        table.addCell("Domicilio:\n" + empresa.getDomicilio());
        table.addCell("");
        table.addCell("NIF:\n" + empleado.getDni());
        table.addCell("CIF:\n" + empresa.getCif());
        table.addCell("");
        table.addCell("Numero afiliacion S.S:\n" + empleado.getSs());
        table.addCell("C.C.C:\n" + empresa.getCcc());
        table.addCell("");
        table.addCell("Grupo profesional:\n Subalternos");
        table.addCell("");
        table.addCell("");
        table.addCell("Grupo cotizacion:\n" + String.valueOf(empleado.getCategoria()));
        table.addCell("");
        table.addCell("");
        table.addCell("Fecha de antiguedad:\n" + empleado.getFecha_alta());
        int totalDias = Integer.parseInt(nomina.getFecha_final().substring(8)) - Integer.parseInt(nomina.getFecha_inicio().substring(8)) + 1;
        Chunk c1 = new Chunk("\nPeriodo de liquidación del " + nomina.getFecha_inicio() + " al " + nomina.getFecha_final() + " ................................................. Total dias: " + totalDias + "\n");
        frase1.add(c1);
        parrafo.add(frase1);

        table2.getDefaultCell().setBorder(0);
        table2.setWidthPercentage(100);
        table2.addCell(new Phrase("I. DEVENGOS", negrita));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("TOTALES", negrita));
        table2.addCell("Salario Base: ");
        table2.addCell(String.valueOf(nomina.getSalario_base()));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("P.P Gratificaciones Extraordinarias: ");
        table2.addCell(String.valueOf(nomina.getExtraordinarias()));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("II. DEDUCCIONES", negrita));
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("A. TOTAL DEVENGADO", negrita));
        table2.addCell(String.valueOf(nomina.getTotal_devengado()));
        table2.addCell("Contingencias comunes: ");
        table2.addCell("4.7 %");
        table2.addCell(String.valueOf(nomina.getContingencias_comunes()));
        table2.addCell("Total aportaciones ");
        table2.addCell(String.valueOf(nomina.getTotal_aportaciones()));
        table2.addCell("Desempleo: ");
        if (empleado.getTipo_de_contrato().equals("Temporal")) {
            table2.addCell("1.60 %");
        } else {
            table2.addCell("1.55 %");
        }
        table2.addCell(String.valueOf(nomina.getDesempleo()));
        table2.addCell("IRPF:");
        table2.addCell(String.valueOf(nomina.getIrpf()));
        table2.addCell("Formación profesional: ");
        table2.addCell("0.1 %");
        table2.addCell(String.valueOf(nomina.getFormacion_profesional()));
        table2.addCell("Anticipos: ");
        table2.addCell("");
        table2.addCell("Horas extraordinarias: ");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("Valor en especies: ");
        table2.addCell("");
        table2.addCell("Fuerza mayor: ");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("Otras deducciones: ");
        table2.addCell("");
        table2.addCell("Otras horas extras: ");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        Phrase frase2 = new Phrase();
        Paragraph parrafo2 = new Paragraph();
        Chunk c2 = new Chunk("\n                                                            B. Total a adeducir: ...... " + nomina.getTotal_a_deducir() + "\n"
                + "                                                                         Liquidación total a deducir: ...... " + nomina.getLiquido_total_a_percibir()
                + "\n                                                      firma y sello de la empresa                       " + nomina.getFecha_final() + "            RECIBI. "
        );
        frase2.add(c2);
        parrafo2.add(frase2);

        PdfPTable table3 = new PdfPTable(6);

        table3.getDefaultCell().setBorder(0);
        table3.setWidthPercentage(100);
        table3.addCell(new Phrase("1. Contingencias comunes", negrita));
        table2.addCell("");
        table2.addCell("");
        table3.addCell("2. Contingencias porfesionales y conceptos de recaud. conjunta");
        table2.addCell("");
        table2.addCell("");
        //salto
        table2.addCell("");
        table2.addCell("");
        table2.addCell("Aportación empresa");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("Aportación empresa");
        //salto
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("Base contingencias porfesionales ");
        table2.addCell(String.valueOf(nomina.getTotal_devengado()));
        table2.addCell("");
        //salto
        table2.addCell("Remuneración");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");

        table2.addCell(new Phrase("TOTALES", negrita));
        table2.addCell("Salario Base: ");
        table2.addCell(String.valueOf(nomina.getSalario_base()));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("P.P Gratificaciones Extraordinarias: ");
        table2.addCell(String.valueOf(nomina.getExtraordinarias()));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("II. DEDUCCIONES", negrita));
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("A. TOTAL DEVENGADO", negrita));
        table2.addCell(String.valueOf(nomina.getTotal_devengado()));
        table2.addCell("Contingencias comunes: ");
        table2.addCell("4.7 %");
        table2.addCell(String.valueOf(nomina.getContingencias_comunes()));
        table2.addCell("Total aportaciones ");
        table2.addCell(String.valueOf(nomina.getTotal_aportaciones()));
        table2.addCell("Desempleo: ");

        /*frase1.add(c1);
        frase1.add(c14);
        frase1.add(c2);
        frase1.add(c3);
        frase1.add(c4);
        frase1.add(c5);
        frase1.add(c6);
        frase1.add(c7);
        frase1.add(c8);
        frase1.add(c9);
        frase1.add(c10);
        frase1.add(c11);
        frase1.add(c12);
        frase1.add(c13);
        Paragraph parrafo = new Paragraph();
        parrafo.add(frase1);*/
        document.add(table);
        document.add(parrafo);
        document.add(table2);
        document.add(parrafo2);

        document.close();

    }

    private void createDirectoryUser(Empleado empleado) throws IOException {
        String[] apellido = empleado.getApellidos().split(" ");
        String fileName = "./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni();
        Path path = Paths.get(fileName);
        if (!Files.exists(path)) {
            Files.createDirectory(path);
        }
    }

    private void passZip(Empleado empleado) throws IOException {
        String[] apellido = empleado.getApellidos().split(" ");
        String sourceDirPath = "./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni();
        String zipFilePath = "./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni() + ".zip";
        Path pathZip = Paths.get(zipFilePath);
        if (Files.exists(pathZip)) {
            Files.delete(pathZip);
        }
        Path p = Files.createFile(Paths.get(zipFilePath));
        Path pp = Paths.get(sourceDirPath);
        try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p)); Stream<Path> paths = Files.walk(pp)) {
            paths
                    .filter(path -> !Files.isDirectory(path))
                    .forEach(path -> {
                        ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
                        try {
                            zs.putNextEntry(zipEntry);
                            Files.copy(path, zs);
                            zs.closeEntry();
                        } catch (IOException e) {
                            System.err.println(e);
                        }
                    });
        }

    }
}
