package com.example.Nominas;

import com.itextpdf.text.DocumentException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import javax.xml.parsers.ParserConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

@RestController
@RequestMapping("/")
public class NominasController {
    
    @Autowired
    NominasService service;
    
    @PostMapping("/generate")
    public ResponseEntity insertarNomina() throws ParseException, ParserConfigurationException, SAXException, IOException, DocumentException{
        service.nominasInformation();
        return ResponseEntity.ok("Todo ok");
    }
    
    @GetMapping("/empleado/{id}")
    public ResponseEntity generarNomina_empleado(@PathVariable(value="id") Long id) throws FileNotFoundException, DocumentException, IOException {
        service.usuario(id);
        return ResponseEntity.ok().build();
    }
   @GetMapping("/nominas")
    public ResponseEntity generarNomina() throws IOException, FileNotFoundException, DocumentException{
        service.generaAllNominas();
        return ResponseEntity.ok("Todo guay");
    }
}
