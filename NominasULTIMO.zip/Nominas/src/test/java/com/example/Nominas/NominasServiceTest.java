/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.example.Nominas;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.text.ParseException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author Rubén
 */
public class NominasServiceTest {
    
    public NominasServiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    @Test
    public void testFechaMayor() throws ParseException{
        NominasService prueba = new NominasService();
        
        boolean resultat = prueba.fechaInicioFinal("2022-06-10", 5, 15);
        assertTrue(resultat);
    }
    
    @Test
    public void testFechaMenor() throws ParseException{
        NominasService prueba = new NominasService();
        
        boolean resultat = prueba.fechaInicioFinal("2022-02-10", 5, 15);
        assertFalse(resultat);
    }
    
    @Test
    public void testFechaIgual() throws ParseException{
        NominasService prueba = new NominasService();
        
        boolean resultat = prueba.fechaInicioFinal("2022-05-15", 5, 15);
        assertFalse(resultat);
    }

    @Test
    public void chequeoXML() throws ParserConfigurationException, SAXException, IOException{
        NominasService prueba = new NominasService();
        Empleado empleado = new Empleado();
        empleado.setCategoria(1);
        empleado.setNivel(1);
        empleado.setLetra('0');
        String salario = prueba.salarioXML(empleado);
        assertEquals("25851.50",salario);
    }
    
    @Test
    public void finalMes() {
        NominasService prueba = new NominasService();
        int diasDelMes = prueba.fechaFinalMes(6);
        assertEquals(30,diasDelMes);
    }
    
    @Test
    public void finalMes2() {
        NominasService prueba = new NominasService();
        int diasDelMes = prueba.fechaFinalMes(2);
        assertEquals(28,diasDelMes);
    }
    
    @Test
    public void finalMes3() {
        NominasService prueba = new NominasService();
        int diasDelMes = prueba.fechaFinalMes(7);
        assertEquals(31,diasDelMes);
    }
    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
