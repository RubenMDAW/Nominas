package com.example.Nominas;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface NominasRepository extends JpaRepository<Nominas, Long>{
    
    @Override
    <S extends Nominas> S save(S s);
    
    @Override
    Optional<Nominas> findById(Long id);
    
    //@Override
    List<Nominas> findByIdtrabajador(Long idtrabajador);
    
    @Query (value="SELECT * FROM `nominas` WHERE MONTH(fecha_inicio) = MONTH(NOW()) AND YEAR(fecha_inicio) = YEAR(NOW())", nativeQuery=true)
    List<Nominas> listNominasMes();
    
    @Override
    List<Nominas> findAll();
}
