package com.example.Nominas;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import org.apache.commons.math3.util.Precision;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

@Service
public class NominasService {

    @Autowired
    NominasRepository repository;

    @Autowired
    EmpleadoRepository repositoryEmpleado;

    @Autowired
    EmpresaRepository repositoryEmpresa;

    public void nominasInformation() throws ParseException, ParserConfigurationException, SAXException, IOException, DocumentException {

        List<Empleado> listaEmpleados = getAllEmpleados();

        List<Nominas> listaDeNominas = repository.listNominasMes();
        Iterable<Nominas> iterableNominasABorrar = listaDeNominas;
        repository.deleteAll(iterableNominasABorrar);

        for (int i = 0; i < numeroEmpleado(listaEmpleados); i++) {

            Nominas nominaGenerada = new Nominas();
            Empleado empleadoActual = listaEmpleados.get(i);
            Empresa empresa = repositoryEmpresa.findById(Long.valueOf(empleadoActual.getId_empresa())).get();
            int mesActual = LocalDate.now().getMonthValue();
            if (fechaInicioFinal(empleadoActual.getFecha_baja(), mesActual, fechaFinalMes(mesActual))) {
                setNomina(nominaGenerada, empleadoActual, empresa);
                repository.save(nominaGenerada);
            }
        }
    }

    private void setNomina(Nominas nominaGenerada, Empleado empleadoActual, Empresa empresa) throws ParseException, NumberFormatException, ParserConfigurationException, SAXException, IOException {
        nominaGenerada.setId_empresa(empleadoActual.getId_empresa());
        nominaGenerada.setId_trabajador(empleadoActual.getId());
        int mesActual = LocalDate.now().getMonthValue();
        if (fechaInicioFinal(empleadoActual.getFecha_alta(), mesActual, 01)) {
            nominaGenerada.setFecha_inicio(empleadoActual.getFecha_alta());
        } else {
            nominaGenerada.setFecha_inicio("2022-0" + mesActual + "-01");
        }

        if (fechaInicioFinal(empleadoActual.getFecha_baja(), mesActual, fechaFinalMes(mesActual))) {
            nominaGenerada.setFecha_final("2022-0" + mesActual + "-" + fechaFinalMes(mesActual));
        } else {
            nominaGenerada.setFecha_final(empleadoActual.getFecha_baja());
        }

        // EMPRESA
        nominaGenerada.setEmpresa(empresa.getNombre());
        nominaGenerada.setDomicilio(empresa.getDomicilio());
        nominaGenerada.setCif(empresa.getCif());
        nominaGenerada.setCcc(empresa.getCcc());

        // TRABAJADOR
        nominaGenerada.setTrabajador(empleadoActual.getNombre() + " " + empleadoActual.getApellidos());
        nominaGenerada.setNif(empleadoActual.getDni());
        nominaGenerada.setSs(empleadoActual.getSs());
        nominaGenerada.setCategoria_profesional(empleadoActual.getGrupo_profesional());
        nominaGenerada.setGrupo_cotizacion(empleadoActual.getCategoria());
        nominaGenerada.setFecha_antiguedad(empleadoActual.getFecha_alta());

        // DEVENGOS
        String salario_baseString = salarioXML(empleadoActual);
        float salario_base = Precision.round(Float.valueOf(salario_baseString) / 15, 2);
        float extraordinarias = Precision.round(salario_base / 12, 2);
        nominaGenerada.setSalario_base(salario_base);
        if (mesActual == 6 || mesActual == 12) {
            nominaGenerada.setVacaciones(salario_base);
        } else {
            nominaGenerada.setVacaciones(0);
        }
        nominaGenerada.setExtraordinarias(extraordinarias);
        if (empleadoActual.getPlus_capacitacion_profesional().equals("SI")) {
            nominaGenerada.setPlus_capacitacion_profesional(Precision.round(salario_base * 0.2f, 2));
        } else {
            nominaGenerada.setPlus_capacitacion_profesional(0);
        }

        nominaGenerada.setPlus_transporte(Precision.round(2.49f * 22, 2));

        if (empleadoActual.getPlus_dieta() >= 26.67) {
            int totalDias = Integer.parseInt(nominaGenerada.getFecha_final().substring(8)) - Integer.parseInt(nominaGenerada.getFecha_inicio().substring(8)) + 1;
            nominaGenerada.setPlus_dieta(Precision.round((empleadoActual.getPlus_dieta() - 26.67f) * totalDias, 2));
        } else {
            nominaGenerada.setPlus_dieta(0);
        }

        nominaGenerada.setHoras_extras_numero((int) Math.random() * 16);
        nominaGenerada.setHoras_extras(Precision.round((nominaGenerada.getSalario_base() / 30f / 8f) * 1.5f, 2));
        nominaGenerada.setTotal_devengado(Precision.round(nominaGenerada.getSalario_base() + nominaGenerada.getExtraordinarias()+nominaGenerada.getVacaciones()+nominaGenerada.getPlus_dieta()+nominaGenerada.getPlus_capacitacion_profesional()+nominaGenerada.getPlus_transporte(), 2));

        float baseContingenciasComunes = nominaGenerada.getSalario_base() + nominaGenerada.getPlus_capacitacion_profesional() + nominaGenerada.getPlus_transporte() + nominaGenerada.getExtraordinarias() + nominaGenerada.getVacaciones() + nominaGenerada.getPlus_dieta();
        float baseHorasExtras = nominaGenerada.getHoras_extras();
        float baseContingenciasProfesionales = baseContingenciasComunes + baseHorasExtras;

        nominaGenerada.setContingencias_comunes(Precision.round(4.70f * baseContingenciasComunes / 100, 2));
        if (empleadoActual.getTipo_de_contrato().equals("Temporal")) {
            nominaGenerada.setDesempleo(Precision.round(1.60f * baseContingenciasProfesionales / 100, 2));
        } else {
            nominaGenerada.setDesempleo(Precision.round(1.55f * baseContingenciasProfesionales / 100, 2));
        }
        nominaGenerada.setFormacion_profesional(Precision.round(0.10f * baseContingenciasProfesionales / 100, 2));
        nominaGenerada.setTotal_aportaciones(Precision.round(nominaGenerada.getContingencias_comunes() + nominaGenerada.getDesempleo() + nominaGenerada.getFormacion_profesional(), 2));

        nominaGenerada.setIrpf(Precision.round(2f * baseContingenciasProfesionales / 100, 2)); //PORCENTAJE GUARDAR BBDD
        nominaGenerada.setTotal_a_deducir(Precision.round(nominaGenerada.getTotal_aportaciones() + nominaGenerada.getIrpf(), 2));

        nominaGenerada.setLiquido_total_a_percibir(Precision.round(nominaGenerada.getTotal_devengado() - nominaGenerada.getTotal_a_deducir(), 2));

        // CONTINGENCIAS EMPRESA
        nominaGenerada.setRemuneracion_personal(nominaGenerada.getSalario_base() + nominaGenerada.getVacaciones());
        nominaGenerada.setProrrata_pagas_extras(nominaGenerada.getExtraordinarias());

        nominaGenerada.setBase_cotizacion_ss(Precision.round(23.60f * nominaGenerada.getTotal_devengado() / 100, 2));
        nominaGenerada.setAt_ep(Precision.round(1.5f * baseContingenciasProfesionales / 100, 2));
        if (empleadoActual.getTipo_de_contrato().equals("Indefinido")) {
            nominaGenerada.setE_desempleo(Precision.round(5.50f * baseContingenciasProfesionales / 100, 2));
        } else {
            nominaGenerada.setE_desempleo(Precision.round(6.70f * baseContingenciasProfesionales / 100, 2));
        }
        nominaGenerada.setE_formacion_profesional(Precision.round(0.6f * baseContingenciasProfesionales / 100, 2));
        nominaGenerada.setFondo_garantia_social(Precision.round(0.2f * baseContingenciasProfesionales / 100, 2));
        nominaGenerada.setCotizacion_adicion_horas_extras(Precision.round(23.6f * baseHorasExtras / 100, 2));
        nominaGenerada.setTotal_aportacion_empresarial(Precision.round(nominaGenerada.getBase_cotizacion_ss() + nominaGenerada.getAt_ep() + nominaGenerada.getE_desempleo() + nominaGenerada.getE_formacion_profesional() + nominaGenerada.getFondo_garantia_social() + nominaGenerada.getCotizacion_adicion_horas_extras(), 2));
    }

    public int fechaFinalMes(int mes) {
        switch (mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 2:
                return 28;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 0;
        }
    }

    public boolean fechaInicioFinal(String fechaIncorporacion, int mesActual, int dia) throws ParseException {
        String fechaI1 = fechaIncorporacion;
        String fechaF2 = "2022-" + mesActual + "-" + dia;
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

        Date fecha1 = formato.parse(fechaI1);
        Date fecha2 = formato.parse(fechaF2);

        if (fecha1.after(fecha2)) {
            return true;
        }
        return false;
    }

    public String salarioXML(Empleado empleadoActual) throws ParserConfigurationException, SAXException, IOException {

        final String FILENAME = "/home/ismael/Escritorio/convenio.xml";
        int empleado_grupo = empleadoActual.getCategoria();
        int empleado_nivel = empleadoActual.getNivel();
        char empleado_letraChar = empleadoActual.getLetra();
        String empleado_letra = Character.toString(empleado_letraChar);

        // instancia la factoria
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        // Parsear el fichero de XML
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File(FILENAME));

        // Quitar infromacion redundante
        doc.getDocumentElement().normalize();
        // doc  busca root devuelve nombre de la raiz o root

        NodeList nodeListGrupoProfesional = doc.getElementsByTagName("grupo_profesional");

        Node nNode_grupo_profesional = nodeListGrupoProfesional.item(empleado_grupo - 1);

        Element element_NivelCat = (Element) nNode_grupo_profesional;

        NodeList nNode_grupo_profesional_hijos = element_NivelCat.getElementsByTagName("niveles_de_categorias");

        Element element_Nivel = (Element) nNode_grupo_profesional_hijos.item(0);

        NodeList nodeNivel = element_Nivel.getElementsByTagName("nivel");
        for (int i = 0; i < nodeNivel.getLength(); i++) {

            Node nodos_Niveles = nodeNivel.item(i);

            Element elementoNivel = (Element) nodos_Niveles;

            String nivel = elementoNivel.getAttribute("numero");

            NodeList nNode_grupo_profesional_salarios = element_NivelCat.getElementsByTagName("salario");

            for (int j = 0; j < nNode_grupo_profesional_salarios.getLength(); j++) {
                Element element_salarioActual = (Element) nNode_grupo_profesional_salarios.item(j);
                if (Integer.parseInt(element_salarioActual.getAttribute("nivel")) == empleado_nivel) {
                    String letra = element_salarioActual.getAttribute("letra");
                    if (empleado_letra.equals("0") || letra.equals(empleado_letra)) {
                        return element_salarioActual.getTextContent();
                    }
                }
            }

        }
        return "";
    }

    public List getAllEmpleados() {
        List<Empleado> listaEmpleados = repositoryEmpleado.findAll();
        return listaEmpleados;
    }

    public static int numeroEmpleado(List<Empleado> list) {
        return list.size();
    }

    public List getNominasABorrar() {
        List<Nominas> listaNominasABorrar = repository.listNominasMes();
        return listaNominasABorrar;
    }

    public void generarPDF(Nominas nomina, Empleado empleado, Empresa empresa) throws FileNotFoundException, DocumentException {

        com.itextpdf.text.Document document = new com.itextpdf.text.Document();
        String[] apellido = empleado.getApellidos().split(" ");
        String[] fecha = nomina.getFecha_final().split("-");
        PdfWriter.getInstance(document, new FileOutputStream("./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni() + "/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + fecha[1] + "_" + fecha[0] + ".pdf"));
        document.open();

        Phrase frase1 = new Phrase();
        Paragraph parrafo = new Paragraph();
        PdfPTable table = new PdfPTable(3);
        PdfPTable table2 = new PdfPTable(5);
        PdfPTable table4 = new PdfPTable(3);
        Font negrita = new Font(Font.FontFamily.COURIER, 12, Font.BOLDITALIC);
        Font letraNormal = new Font(Font.FontFamily.COURIER, 9);
        Font letraNormalNegrita = new Font(Font.FontFamily.COURIER, 9, Font.BOLD);

        table.getDefaultCell().setBorder(0);
        table.setWidthPercentage(100);
        table.addCell(new Phrase("EMPRESA", negrita));
        table.addCell("");
        table.addCell(new Phrase("EMPLEADO", negrita));
        table.addCell(new Phrase("Nombre:\n" + empresa.getNombre(), letraNormal));
        table.addCell("");
        table.addCell(new Phrase("Nombre:\n" + empleado.getNombre() + " " + empleado.getApellidos(), letraNormal));
        table.addCell(new Phrase("Domicilio:\n" + empresa.getDomicilio(), letraNormal));
        table.addCell("");
        table.addCell(new Phrase("NIF:\n" + empleado.getDni(), letraNormal));
        table.addCell(new Phrase("CIF:\n" + empresa.getCif(), letraNormal));
        table.addCell("");
        table.addCell(new Phrase("Numero afiliacion S.S:\n" + empleado.getSs(), letraNormal));
        table.addCell(new Phrase("C.C.C:\n" + empresa.getCcc(), letraNormal));
        table.addCell("");
        table.addCell(new Phrase("Grupo profesional:\n"+nomina.getCategoria_profesional(), letraNormal));
        table.addCell("");
        table.addCell("");
        table.addCell(new Phrase("Grupo cotizacion:\n" + String.valueOf(empleado.getCategoria()), letraNormal));
        table.addCell("");
        table.addCell("");
        table.addCell(new Phrase("Fecha de antiguedad:\n" + empleado.getFecha_alta(), letraNormal));
        int totalDias = Integer.parseInt(nomina.getFecha_final().substring(8)) - Integer.parseInt(nomina.getFecha_inicio().substring(8)) + 1;
        Chunk c1 = new Chunk("\nPeriodo de liquidación del " + nomina.getFecha_inicio() + " al " + nomina.getFecha_final() + " .................... Total dias: " + totalDias + "\n\n", letraNormal);
        frase1.add(c1);
        parrafo.add(frase1);

        table2.getDefaultCell().setBorder(0);
        table2.setWidths(new float[]{3f, 1f, 2f, 3f, 2f});
        table2.setWidthPercentage(100);
        table2.addCell(new Phrase("I. DEVENGOS", negrita));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("TOTALES", negrita));
        table2.addCell(new Phrase("Salario Base: ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getSalario_base()), letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        if(nomina.getVacaciones() > 0){
            table2.addCell(new Phrase("Paga extraordinaria: ", letraNormal));
            table2.addCell(new Phrase(String.valueOf(nomina.getVacaciones()), letraNormal));
            table2.addCell("");
            table2.addCell("");
            table2.addCell("");
        }
        table2.addCell(new Phrase("P.P Gratificaciones Extraordinarias: ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getExtraordinarias()), letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("Horas extras : ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getHoras_extras()), letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("Plus capacitación profesional: ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getPlus_capacitacion_profesional()), letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("Plus transporte: ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getPlus_transporte()), letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("Plus dietas: ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getPlus_dieta()), letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("II. DEDUCCIONES", negrita));
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("A. TOTAL DEVENGADO", negrita));
        table2.addCell(new Phrase(String.valueOf(nomina.getTotal_devengado()), letraNormal));
        table2.addCell(new Phrase("Contingencias comunes: ", letraNormal));
        table2.addCell(new Phrase("4.7 %", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getContingencias_comunes()), letraNormal));
        table2.addCell(new Phrase("Total aportaciones ", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getTotal_aportaciones()), letraNormal));
        table2.addCell(new Phrase("Desempleo: ", letraNormal));
        if (empleado.getTipo_de_contrato().equals("Temporal")) {
            table2.addCell(new Phrase("1.60 %", letraNormal));
        } else {
            table2.addCell(new Phrase("1.55 %", letraNormal));
        }
        table2.addCell(new Phrase(String.valueOf(nomina.getDesempleo()), letraNormal));
        table2.addCell(new Phrase("IRPF:", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getIrpf()), letraNormal));
        table2.addCell(new Phrase("Formación profesional: ", letraNormal));
        table2.addCell(new Phrase("0.1 %", letraNormal));
        table2.addCell(new Phrase(String.valueOf(nomina.getFormacion_profesional()), letraNormal));
        table2.addCell(new Phrase("Anticipos: ", letraNormal));
        table2.addCell("");
        table2.addCell(new Phrase("Horas extraordinarias: ", letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("Valor en especies: ", letraNormal));
        table2.addCell("");
        table2.addCell(new Phrase("Fuerza mayor: ", letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell(new Phrase("Otras deducciones: ", letraNormal));
        table2.addCell("");
        table2.addCell(new Phrase("Otras horas extras: ", letraNormal));
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");
        table2.addCell("");

        table4.getDefaultCell().setBorder(0);
        table4.setWidths(new float[]{3.6f, 1.8f, 1.2f});
        table4.setWidthPercentage(100);
        table4.addCell("");
        table4.addCell(new Phrase("B. Total a deducir:", letraNormal));
        table4.addCell(new Phrase(String.valueOf(nomina.getTotal_a_deducir()), letraNormal));
        table4.addCell("");
        table4.addCell(new Phrase("Líquido total a percibir", letraNormal));
        table4.addCell(new Phrase(String.valueOf(nomina.getLiquido_total_a_percibir()), letraNormal));
        table4.addCell(new Phrase("\t\t\t\nFirma y sello de la empresa", letraNormal));
        table4.addCell(new Phrase("\n" + nomina.getFecha_final(), letraNormal));
        table4.addCell(new Phrase("\nRECIBI", letraNormal));

        Phrase frase2 = new Phrase();
        Paragraph parrafo2 = new Paragraph();
        Chunk c2 = new Chunk("\n\n");
        frase2.add(c2);
        parrafo2.add(frase2);

        PdfPTable table3 = new PdfPTable(6);

        table3.setWidths(new float[]{3f, 1f, 2f, 3f, 1f, 2f});
        table3.getDefaultCell().setBorder(0);
        table3.setWidthPercentage(100);
        PdfPCell celda1 = new PdfPCell(new Phrase("1. Contingencias comunes", negrita));
        celda1.setColspan(3);
        celda1.setBorder(0);
        table3.addCell(celda1);
        PdfPCell celda2 = new PdfPCell(new Phrase("2. Contingencias profesionales y conceptos de recaud. conjunta", negrita));
        celda2.setColspan(3);
        celda2.setBorder(0);
        table3.addCell(celda2);
        //salto
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase("Aport. empresa", letraNormal));
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase(" Aport. empresa", letraNormal));
        //salto
        table3.addCell("");
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase("Base contingencias profesionales ", letraNormal));
        table3.addCell(new Phrase(String.valueOf(nomina.getTotal_devengado()), letraNormal));
        table3.addCell("");
        //salto
        table3.addCell(new Phrase("Remuneración mensual", letraNormal));
        table3.addCell(new Phrase(String.valueOf(nomina.getSalario_base()), letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" AT y EP ", letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" 1.50%..." + nomina.getAt_ep(), letraNormal));
        //salto
        table3.addCell(new Phrase("Prorrata pagas extrad.", letraNormal));
        table3.addCell(new Phrase(String.valueOf(nomina.getExtraordinarias()), letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" Desempleo", letraNormal));
        table3.addCell("");
        if (empleado.getTipo_de_contrato().equals("Temporal")) {
            table3.addCell(new Phrase(" 6.70%", letraNormal));
        } else {
            table3.addCell(new Phrase(" 5.55%", letraNormal));
        }

        //salto
        table3.addCell(new Phrase("Base incapacidad temporal", letraNormal));
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase(" Formacion profesional", letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" 0,60%..." + nomina.getE_formacion_profesional(), letraNormal));
        //salto

        table3.addCell(new Phrase("Base cotización S.S", letraNormal));
        table3.addCell(new Phrase(String.valueOf(nomina.getTotal_devengado()), letraNormal));
        table3.addCell(new Phrase(" 23,60%..." + nomina.getBase_cotizacion_ss(), letraNormal));
        table3.addCell(new Phrase(" Fondos Garantia Social", letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" 0,20%..." + nomina.getFondo_garantia_social(), letraNormal));

        //salto
        table3.addCell(new Phrase("Base Exp. Regulación Empleo", letraNormal));
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase("3.Cotización adicional horas extra.", letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" 23.60%..." + nomina.getCotizacion_adicion_horas_extras(), letraNormal));

        //salto
        table3.addCell("");
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase(" Total aportación empresarial", letraNormal));
        table3.addCell("");
        table3.addCell(new Phrase(" " + String.valueOf(nomina.getTotal_aportacion_empresarial()), letraNormal));
        // salto 

        table3.addCell("");
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase("4.Base sujeta a retención  del IRPF", letraNormal));
        table3.addCell(new Phrase(String.valueOf(nomina.getTotal_devengado()), letraNormal));
        table3.addCell("");
        //salto

        table3.addCell("");
        table3.addCell("");
        table3.addCell("");
        table3.addCell(new Phrase("5. Base IRPF por retib. en especie", letraNormal));
        table3.addCell("");
        table3.addCell("");

        document.add(table);
        document.add(parrafo);
        document.add(table2);
        document.add(table4);
        document.add(parrafo2);
        document.add(table3);

        document.close();

    }

    private void createDirectoryUser(Empleado empleado) throws IOException {
        String[] apellido = empleado.getApellidos().split(" ");
        String fileName = "./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni();
        Path path = Paths.get(fileName);
        if (!Files.exists(path)) {
            Files.createDirectory(path);
        }
    }

    private void passZip(Empleado empleado) throws IOException {
        String[] apellido = empleado.getApellidos().split(" ");
        String sourceDirPath = "./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni();
        String zipFilePath = "./Nominas/" + empleado.getNombre() + "_" + apellido[0] + "_" + apellido[1] + "_" + empleado.getDni() + ".zip";
        Path pathZip = Paths.get(zipFilePath);
        if (Files.exists(pathZip)) {
            Files.delete(pathZip);
        }
        Path p = Files.createFile(Paths.get(zipFilePath));
        Path pp = Paths.get(sourceDirPath);
        try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p)); Stream<Path> paths = Files.walk(pp)) {
            paths
                    .filter(path -> !Files.isDirectory(path))
                    .forEach(path -> {
                        ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
                        try {
                            zs.putNextEntry(zipEntry);
                            Files.copy(path, zs);
                            zs.closeEntry();
                        } catch (IOException e) {
                            System.err.println(e);
                        }
                    });
        }

    }

    public void usuario(Long id) throws FileNotFoundException, DocumentException, IOException {
        List<Nominas> listaNominasDelEmpleado = repository.findByIdtrabajador(id);
        for (int i = 0; i < listaNominasDelEmpleado.size(); i++) {
            Empleado empleado;
            Optional<Empleado> empleadoOptional = repositoryEmpleado.findById(id);
            if (empleadoOptional.isPresent()) {
                empleado = empleadoOptional.get();
                Empresa empresa = repositoryEmpresa.findById(Long.valueOf(listaNominasDelEmpleado.get(i).getId_empresa())).get();
                createDirectoryUser(empleado);
                generarPDF(listaNominasDelEmpleado.get(i), empleado, empresa);
                passZip(empleado);
            } else {
                empleado = null;
            }
        }
    }

    public void generaAllNominas() throws IOException, FileNotFoundException, DocumentException {
        List<Nominas> listaNominasTotales = repository.findAll();
        for (int i = 0; i < listaNominasTotales.size(); i++) {
            Empleado empleado;
            Optional<Empleado> empleadoOptional = repositoryEmpleado.findById(listaNominasTotales.get(i).getId_trabajador());
            if (empleadoOptional.isPresent()) {
                empleado = empleadoOptional.get();
                Empresa empresa = repositoryEmpresa.findById(Long.valueOf(listaNominasTotales.get(i).getId_empresa())).get();
                createDirectoryUser(empleado);
                generarPDF(listaNominasTotales.get(i), empleado, empresa);
                passZip(empleado);
            } else {
                empleado = null;
            }

        }

    }
}
