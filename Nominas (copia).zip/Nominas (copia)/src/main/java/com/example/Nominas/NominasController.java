package com.example.Nominas;


import java.io.IOException;
import java.text.ParseException;
import javax.xml.parsers.ParserConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Rubén
 */
@RestController
@RequestMapping("/")
public class NominasController {
    
    @Autowired
    NominasService service;
    
    @PostMapping("/generate")
    public ResponseEntity generarNomina() throws ParseException, ParserConfigurationException, SAXException, IOException{
        service.nominasInformation();
        return ResponseEntity.ok().build();
    }
}
