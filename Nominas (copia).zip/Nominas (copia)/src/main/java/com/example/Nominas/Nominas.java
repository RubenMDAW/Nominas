/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Nominas;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Rubén
 */
@Entity
@Table(name = "nominas")
public class Nominas {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // RELACIONES
    @Column(name = "id_empresa")
    private int id_empresa;
    
    @Column(name = "id_trabajador")
    private int id_trabajador;

    // FECHAS
    @Column(name = "fecha_inicio")
    private String fecha_inicio;
    
    @Column(name = "fecha_final")
    private String fecha_final;
    
    // EMPRESA
    @Column(name = "empresa")
    private String empresa;
    
    @Column(name = "domicilio")
    private String domicilio;
    
    @Column(name = "cif")
    private String cif;
    
    @Column(name = "ccc")
    private String ccc;
    
    // TRABAJADOR
    @Column(name = "trabajador")
    private String trabajador;
    
    @Column(name = "nif")
    private String nif;
    
    @Column(name = "ss")
    private String ss;
    
    @Column(name = "categoria_profesional")
    private String categoria_profesional;
    
    @Column(name = "grupo_cotizacion")
    private int grupo_cotizacion;
    
    @Column(name = "fecha_antiguedad")
    private String fecha_antiguedad;
    
    // DEVENGOS
    @Column(name = "salario_base")
    private float salario_base;
    
    @Column(name = "vacaciones")
    private float vacaciones;
    
    @Column(name = "extraordinarias")
    private float extraordinarias;
    
    @Column(name = "total_devengado")
    private float total_devengado; // Sumado lo anterior
    
    // DEDUCCIONES
    @Column(name = "contingencias_comunes")
    private float contingencias_comunes;
    
    @Column(name = "desempleo")
    private float desempleo;
    
    @Column(name = "formacion_profesional")
    private float formacion_profesional;
    
    @Column(name = "horas_extras")
    private float horas_extras;
    
    @Column(name = "total_aportaciones")
    private float total_aportaciones; // Sumado lo anterior
    
    @Column(name = "irpf")
    private float irpf;
    
    @Column(name = "total_a_deducir")
    private float total_a_deducir; // Suma de lo anterior
    
    @Column(name = "liquido_total_a_percibir")
    private float liquido_total_a_percibir; //total_aport - total_a_deducir
    
    // CONTINGENCIAS COMUNES
    @Column(name = "remuneracion_personal")
    private float remuneracion_personal;
    
    @Column(name = "prorrata_pagas_extras")
    private float prorrata_pagas_extras;
    
    @Column(name = "base_incapacidad_temporal")
    private float base_incapacidad_temporal;
    
    @Column(name = "base_cotizacion_ss")
    private float base_cotizacion_ss;
    
    @Column(name = "base_exp_regulacion_empleo")
    private float base_exp_regulacion_empleo;
    
    // CONTINGENCIAS PROFESIONALES
    @Column(name = "at_ep")
    private float at_ep;
    
    @Column(name = "e_desempleo")
    private float e_desempleo;
    
    @Column(name = "e_formacion_profesional")
    private float e_formacion_profesional;
    
    @Column(name = "fondo_garantia_social")
    private float fondo_garantia_social;
    
    @Column(name = "total_aportacion_empresarial")
    private float total_aportacion_empresarial; // Sumar contingencias comunes y profesionales

    public Long getId() {
        return id;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public int getId_trabajador() {
        return id_trabajador;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public String getFecha_final() {
        return fecha_final;
    }

    public String getEmpresa() {
        return empresa;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getCif() {
        return cif;
    }

    public String getCcc() {
        return ccc;
    }

    public String getTrabajador() {
        return trabajador;
    }

    public String getNif() {
        return nif;
    }

    public String getSs() {
        return ss;
    }

    public String getCategoria_profesional() {
        return categoria_profesional;
    }

    public int getGrupo_cotizacion() {
        return grupo_cotizacion;
    }

    public String getFecha_antiguedad() {
        return fecha_antiguedad;
    }

    public float getSalario_base() {
        return salario_base;
    }

    public float getVacaciones() {
        return vacaciones;
    }

    public float getExtraordinarias() {
        return extraordinarias;
    }

    public float getTotal_devengado() {
        return total_devengado;
    }

    public float getContingencias_comunes() {
        return contingencias_comunes;
    }

    public float getDesempleo() {
        return desempleo;
    }

    public float getFormacion_profesional() {
        return formacion_profesional;
    }

    public float getHoras_extras() {
        return horas_extras;
    }

    public float getTotal_aportaciones() {
        return total_aportaciones;
    }

    public float getIrpf() {
        return irpf;
    }

    public float getTotal_a_deducir() {
        return total_a_deducir;
    }

    public float getLiquido_total_a_percibir() {
        return liquido_total_a_percibir;
    }

    public float getRemuneracion_personal() {
        return remuneracion_personal;
    }

    public float getProrrata_pagas_extras() {
        return prorrata_pagas_extras;
    }

    public float getBase_incapacidad_temporal() {
        return base_incapacidad_temporal;
    }

    public float getBase_cotizacion_ss() {
        return base_cotizacion_ss;
    }

    public float getBase_exp_regulacion_empleo() {
        return base_exp_regulacion_empleo;
    }

    public float getAt_ep() {
        return at_ep;
    }

    public float getE_desempleo() {
        return e_desempleo;
    }

    public float getE_formacion_profesional() {
        return e_formacion_profesional;
    }

    public float getFondo_garantia_social() {
        return fondo_garantia_social;
    }

    public float getTotal_aportacion_empresarial() {
        return total_aportacion_empresarial;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public void setId_trabajador(int id_trabajador) {
        this.id_trabajador = id_trabajador;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public void setFecha_final(String fecha_final) {
        this.fecha_final = fecha_final;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public void setCcc(String ccc) {
        this.ccc = ccc;
    }

    public void setTrabajador(String trabajador) {
        this.trabajador = trabajador;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public void setSs(String ss) {
        this.ss = ss;
    }

    public void setCategoria_profesional(String categoria_profesional) {
        this.categoria_profesional = categoria_profesional;
    }

    public void setGrupo_cotizacion(int grupo_cotizacion) {
        this.grupo_cotizacion = grupo_cotizacion;
    }

    public void setFecha_antiguedad(String fecha_antiguedad) {
        this.fecha_antiguedad = fecha_antiguedad;
    }

    public void setSalario_base(float salario_base) {
        this.salario_base = salario_base;
    }

    public void setVacaciones(float vacaciones) {
        this.vacaciones = vacaciones;
    }

    public void setExtraordinarias(float extraordinarias) {
        this.extraordinarias = extraordinarias;
    }

    public void setTotal_devengado(float total_devengado) {
        this.total_devengado = total_devengado;
    }

    public void setContingencias_comunes(float contingencias_comunes) {
        this.contingencias_comunes = contingencias_comunes;
    }

    public void setDesempleo(float desempleo) {
        this.desempleo = desempleo;
    }

    public void setFormacion_profesional(float formacion_profesional) {
        this.formacion_profesional = formacion_profesional;
    }

    public void setHoras_extras(float horas_extras) {
        this.horas_extras = horas_extras;
    }

    public void setTotal_aportaciones(float total_aportaciones) {
        this.total_aportaciones = total_aportaciones;
    }

    public void setIrpf(float irpf) {
        this.irpf = irpf;
    }

    public void setTotal_a_deducir(float total_a_deducir) {
        this.total_a_deducir = total_a_deducir;
    }

    public void setLiquido_total_a_percibir(float liquido_total_a_percibir) {
        this.liquido_total_a_percibir = liquido_total_a_percibir;
    }

    public void setRemuneracion_personal(float remuneracion_personal) {
        this.remuneracion_personal = remuneracion_personal;
    }

    public void setProrrata_pagas_extras(float prorrata_pagas_extras) {
        this.prorrata_pagas_extras = prorrata_pagas_extras;
    }

    public void setBase_incapacidad_temporal(float base_incapacidad_temporal) {
        this.base_incapacidad_temporal = base_incapacidad_temporal;
    }

    public void setBase_cotizacion_ss(float base_cotizacion_ss) {
        this.base_cotizacion_ss = base_cotizacion_ss;
    }

    public void setBase_exp_regulacion_empleo(float base_exp_regulacion_empleo) {
        this.base_exp_regulacion_empleo = base_exp_regulacion_empleo;
    }

    public void setAt_ep(float at_ep) {
        this.at_ep = at_ep;
    }

    public void setE_desempleo(float e_desempleo) {
        this.e_desempleo = e_desempleo;
    }

    public void setE_formacion_profesional(float e_formacion_profesional) {
        this.e_formacion_profesional = e_formacion_profesional;
    }

    public void setFondo_garantia_social(float fondo_garantia_social) {
        this.fondo_garantia_social = fondo_garantia_social;
    }

    public void setTotal_aportacion_empresarial(float total_aportacion_empresarial) {
        this.total_aportacion_empresarial = total_aportacion_empresarial;
    }

    
    
}
