/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Nominas;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Rubén
 */
@Service
public class NominasService {

    @Autowired
    NominasRepository repository;

    @Autowired
    EmpleadoRepository repositoryEmpleado;

    @Autowired
    EmpresaRepository repositoryEmpresa;

    public void nominasInformation() throws ParseException, ParserConfigurationException, SAXException, IOException {

        List<Empleado> listaEmpleados = getAllEmpleados();
        
        List<Nominas> listaDeNominas = repository.listNominasMes();
        Iterable<Nominas> iterableNominasABorrar = listaDeNominas;
        repository.deleteAll(iterableNominasABorrar);
        
        for (int i = 0; i < numeroEmpleado(listaEmpleados); i++) {

            //Long idActualEmpleado = 1l;
            Nominas nominaGenerada = new Nominas();
            //Empleado empleadoActual = repositoryEmpleado.findById(idActualEmpleado).get();
            Empleado empleadoActual = listaEmpleados.get(i);
            Empresa empresa = repositoryEmpresa.findById(Long.valueOf(empleadoActual.getId_empresa())).get();

            nominaGenerada.setId_empresa(empleadoActual.getId_empresa());
            nominaGenerada.setId_trabajador(Math.toIntExact(empleadoActual.getId()));
            int mesActual = LocalDate.now().getMonthValue();
            if (fechaInicioFinal(empleadoActual.getFecha_alta(), mesActual, 01)) {
                nominaGenerada.setFecha_inicio(empleadoActual.getFecha_alta());
            } else {
                nominaGenerada.setFecha_inicio("2022-" + mesActual + "-01");
            }

            if (fechaInicioFinal(empleadoActual.getFecha_baja(), mesActual, fechaFinalMes(mesActual))) {
                nominaGenerada.setFecha_final("2022-" + mesActual + "-" + fechaFinalMes(mesActual));
            } else {
                nominaGenerada.setFecha_final(empleadoActual.getFecha_baja());
            }

            // EMPRESA
            nominaGenerada.setEmpresa(empresa.getNombre());
            nominaGenerada.setDomicilio(empresa.getDomicilio());
            nominaGenerada.setCif(empresa.getCif());
            nominaGenerada.setCcc(empresa.getCcc());

            // TRABAJADOR
            nominaGenerada.setTrabajador(empleadoActual.getNombre());
            nominaGenerada.setNif(empleadoActual.getDni());
            nominaGenerada.setSs(empleadoActual.getSs());
            nominaGenerada.setCategoria_profesional("SACAR BASEDEDATOS,AGREGAR CAMPO");
            nominaGenerada.setGrupo_cotizacion(empleadoActual.getCategoria());
            nominaGenerada.setFecha_antiguedad(empleadoActual.getFecha_alta());

            // DEVENGOS
            String salario_baseString = salarioXML(empleadoActual);
            float salario_base = Float.valueOf(salario_baseString) / 15;
            float extraordinarias = salario_base / 12;
            nominaGenerada.setSalario_base(salario_base);
            if (mesActual == 6 || mesActual == 12) {
                nominaGenerada.setVacaciones(salario_base);
            } else {
                nominaGenerada.setVacaciones(0);
            }
            nominaGenerada.setExtraordinarias(extraordinarias);
            nominaGenerada.setTotal_devengado(nominaGenerada.getSalario_base() + nominaGenerada.getExtraordinarias());
            nominaGenerada.setContingencias_comunes(4.70f * nominaGenerada.getTotal_devengado() / 100);
            if (empleadoActual.getTipo_de_contrato().equals("Temporal")) {
                nominaGenerada.setDesempleo(1.60f * nominaGenerada.getTotal_devengado() / 100);
            } else {
                nominaGenerada.setDesempleo(1.55f * nominaGenerada.getTotal_devengado() / 100);
            }
            nominaGenerada.setFormacion_profesional(0.10f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setTotal_aportaciones(nominaGenerada.getContingencias_comunes() + nominaGenerada.getDesempleo() + nominaGenerada.getFormacion_profesional());

            nominaGenerada.setIrpf(2f * nominaGenerada.getTotal_devengado() / 100); //PORCENTAJE GUARDAR BBDD
            nominaGenerada.setTotal_a_deducir(nominaGenerada.getTotal_aportaciones() + nominaGenerada.getIrpf());

            nominaGenerada.setLiquido_total_a_percibir(nominaGenerada.getTotal_devengado() - nominaGenerada.getTotal_a_deducir());

            // CONTINGENCIAS EMPRESA
            nominaGenerada.setRemuneracion_personal(nominaGenerada.getSalario_base() + nominaGenerada.getVacaciones());
            nominaGenerada.setProrrata_pagas_extras(nominaGenerada.getExtraordinarias());

            nominaGenerada.setBase_cotizacion_ss(23.60f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setAt_ep(1.5f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setE_desempleo(6.70f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setE_formacion_profesional(0.6f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setFondo_garantia_social(0.2f * nominaGenerada.getTotal_devengado() / 100);
            nominaGenerada.setTotal_aportacion_empresarial(nominaGenerada.getBase_cotizacion_ss() + nominaGenerada.getAt_ep() + nominaGenerada.getE_desempleo() + nominaGenerada.getE_formacion_profesional() + nominaGenerada.getFondo_garantia_social());

            repository.save(nominaGenerada);

        }
    }

    public int fechaFinalMes(int mes) {
        switch (mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 2:
                return 28;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 0;
        }
    }

    public boolean fechaInicioFinal(String fechaIncorporacion, int mesActual, int dia) throws ParseException {
        String fechaI1 = fechaIncorporacion;
        String fechaF2 = "2022-" + mesActual + "-" + dia;
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

        Date fecha1 = formato.parse(fechaI1);
        Date fecha2 = formato.parse(fechaF2);

        if (fecha1.after(fecha2)) {
            return true;
        }
        return false;
    }

    public String salarioXML(Empleado empleadoActual) throws ParserConfigurationException, SAXException, IOException {

        final String FILENAME = "/home/ismael/Escritorio/convenio.xml";
        int empleado_grupo = empleadoActual.getCategoria();
        int empleado_nivel = empleadoActual.getNivel();
        char empleado_letraChar = empleadoActual.getLetra();
        String empleado_letra = Character.toString(empleado_letraChar);

        // instancia la factoria
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        // Parsear el fichero de XML
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File(FILENAME));

        // Quitar infromacion redundante
        doc.getDocumentElement().normalize();
        // doc  busca root devuelve nombre de la raiz o root

        NodeList nodeListGrupoProfesional = doc.getElementsByTagName("grupo_profesional");

        Node nNode_grupo_profesional = nodeListGrupoProfesional.item(empleado_grupo - 1);

        Element element_NivelCat = (Element) nNode_grupo_profesional;

        NodeList nNode_grupo_profesional_hijos = element_NivelCat.getElementsByTagName("niveles_de_categorias");

        Element element_Nivel = (Element) nNode_grupo_profesional_hijos.item(0);

        NodeList nodeNivel = element_Nivel.getElementsByTagName("nivel");
        System.out.println(nodeNivel.getLength());
        for (int i = 0; i < nodeNivel.getLength(); i++) {

            Node nodos_Niveles = nodeNivel.item(i);

            Element elementoNivel = (Element) nodos_Niveles;

            String nivel = elementoNivel.getAttribute("numero");
            System.out.println("nivel");
            if (nodeNivel.getLength() == 1 || Integer.parseInt(nivel) == empleado_nivel) {
                NodeList nodelist_nombrecategoria = elementoNivel.getElementsByTagName("nombre_categoria");
                for (int j = 0; j < nodelist_nombrecategoria.getLength(); j++) {
                    Node nodos_nombrecat = nodelist_nombrecategoria.item(j);

                    Element elementosNombreCat = (Element) nodos_nombrecat;

                    String letra = elementosNombreCat.getAttribute("letra");

                    if (letra.equals(String.valueOf(empleado_letra))) {
                        System.out.println(elementosNombreCat.getTextContent());
                    }
                }
            }// el ombre del los empleados no hace falta comprobar

            NodeList nNode_grupo_profesional_salarios = element_NivelCat.getElementsByTagName("salario");

            for (int j = 0; j < nNode_grupo_profesional_salarios.getLength(); j++) {
                Element element_salarioActual = (Element) nNode_grupo_profesional_salarios.item(j);
                if (Integer.parseInt(element_salarioActual.getAttribute("nivel")) == empleado_nivel) {
                    String letra = element_salarioActual.getAttribute("letra");
                    if (empleado_letra.equals("0") || letra.equals(empleado_letra)) {
                        return element_salarioActual.getTextContent();
                    }
                }
            }

        }
        return "";
    }

    public List getAllEmpleados() {
        List<Empleado> listaEmpleados = repositoryEmpleado.findAll();
        return listaEmpleados;
    }

    public static int numeroEmpleado(List<Empleado> list) {
        return list.size();
    }
    
    public List getNominasABorrar() {
        List<Nominas> listaNominasABorrar = repository.listNominasMes();
        return listaNominasABorrar;
    }
}
